
<?php
include("head.php");
?>


<?php
include("marco-right.php");
?>
   
 <div style="float:left; width:60%; margin:60px auto; padding:1vw">
   <div  style="width: 100%;">     
    <div style="width: 100%; height:100%; margin: auto ; display:inline-block;" >
       <div style=" width:100%; height: 100%; top:0; font-size:20px; text-align:center; float:left;">
        	<h1>¿Quién es Damaris Miranda?</h1>
       		 <hr>
             
          <div id="posteo" style="text-align: left; font-size:0.5vw;">
                Posteado por:  Damaris Miranda<br>
                Fecha: 2021-08-16 <br>
          </div>
        </div>
    </div>
  </div>
  <div style="width: 100%; height:100%;" >
           <div  style="text-align:justify; font-size: 20px;">
                   <p class="eys-parrafo">Soy Damaris Margarita  Miranda Bolaños , tengo 25 años soy horiunda del Cantón Esmeraldas, cuidad de Esmeraldas en el barrio Mina de Piedra sector de Aire libre Alto, mis padres son Mariano Miranda Y Soraya Bolaños y tengo 4 hermanos varones que son Geovanny, Rubén ,Samuel y Josué. Desde muy pequeña he sido formada en una familia con principios cristianos. mi formación academica inicio en la escuela Dr Luis Prado Viteri. Mis estudios de tercer nivel los estoy realizando en la Universidad Tecnica Luis Vargas Torres donde ha sido mi formación para abrir camino en el ambito laboral..    .. </p>
   <div id="blog-seccion2"  style="height: 50px;"></div>

    <h2 style="border-bottom: 1px solid green;"> Mis estudios</h2> 
    


                   <p class="eys-parrafo">Mis estudios secundarios los realice en el  colegio Tecnico Luis Vargas Torres.....</p>

   <div id="blog-seccion3"  style="height: 50px;"></div>

    <h2 style="border-bottom: 1px solid green;"> Mi perfil informático Soy futura ingeniera en sistemas informaticos y estoy inmersa en el ambito del desarrollo web. </h2> 
    


                   <p  class="eys-parrafo">Durante mi carrera universitaria he logrado manejar herramientas como visual studio, Sql server, proximamente java script, html y php ....</p>

   <div id="blog-seccion4"  style="height: 50px;"></div>

    <h2 style="border-bottom: 1px solid green;"> Mis Hooby la musica y la programación web .</h2> 
    

                   <p   class="eys-parrafo">En mis ratos libres me gusta hacer contenido digital en mi pagina de facebook aparte de dedicarme a mis estudios tambien soy adoradora en mi iglesia....</p>
       

                   

               <hr>
               <div style=" bottom: 0; margin-bottom: 0;   width:100%; display: inline-block;" >
                  <div style="width: 40%;  float: left;">
                   <a href="#">&#171;   Previo</a>
                  </div>

                  <div style="width: 40%; float: right; text-align: right;">
                   <a href="apendiendo-cpp">Programa para aprender C++ &#187;</a>
                  </div>

                </div>
           </div>
  </div> 

  </div>




<?php
include("marco-left.php")
?>
 
<script >  

 document.title="Softskill"; 
document.getElementById("foto").src="./images/damaris.jpg";

 document.getElementById("blog-indice").innerHTML="<p><b>Contenido</b></p><hr> <p><a href='#'>inicio</a></p><p><a href='#blog-seccion2'>Estudios</a></p><p><a href='#blog-seccion3'>Conocimiento informático</a></p><p><a href='#blog-seccion4'>Hooby</a></p>";

document.getElementById("elnombre").innerHTML="Damaris Miranda";


 document.getElementById("blog-relacionados").innerHTML="<p><b>Temas relacionados:</b></p><hr> <p><a href='eys-stalin.php'>¿Quién es Stalin Francis?</a></p><p><a href='eys-kevin.php'>¿Quién es Kevin Aguilar?</a></p> ";

 </script>
 
<?php
include("foot.php")
?>
