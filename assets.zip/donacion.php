<?php
include("head.php");
?>



<div style="background-image: url(assets/images/educaysoft/startup.jpeg); background-repeat: none; background-size:cover; background-size:100% 100%;  display: inline-block; vertical-align:top; width:100%; height:900px; ">


<div style="width:60%; padding:20px display: inline-block; margin-top:200px;">



	<div class="w3-card-4 w3-margin" style="width:350px;">
  		<header class="w3-container w3-green">
    		 ¿Porqué quisieras donar a EDUCAYSOFT?
  		</header>
		<div class="w3-container w3-green" style="opacity:0.7;">  
		<p style="text-align:justify; ">EDUCAYSOFT es una organización que se dedica a capacitar de forma gratuita en el amplia área de la tecnología de la Información y Comunicación, los pocos recursos recogidos por tus donaciones servirán para adquirir recursos tecnológicos y mantener un ambiente agradable y propicio para el aprendizaje </p>
		</div>
  		<footer class="w3-container w3-gray">
    
  			  $5, $10, ...Tu voluntad
  		</footer>
	</div>


	<div class="w3-card-4 w3-margin" style="width:350px;" >
  		<header class="w3-container w3-green">
    		 Como puedo donar:
  		</header>
		<div class="w3-container w3-green" style="opacity:0.7;">
		<p> Puedes hacer un pequeño depósito o transferencia directa a: </p>  
		<p><b>Banco PICHINCHA</b>-Cta Ahorro: 2200137268
</p>
			<p><b>PRODUBANCO:</b>- Cta Ahorro: 12110145483</p>
		</div>
  		<footer class="w3-container w3-gray">
    
  		Contacto: 0997919650  -- Stalin Francis.
  		</footer>
	</div>


</div>

</div>
<?php
include("foot.php")
?>
