  <div style="float:right; padding: 1vw: 82px; width: 20%;border-left: 1px solid black;">
    <div id="blog-relacionados" style=" width: 100%; height: 100vh;   padding: 1vw; margin-top:80px;"> 
        <p>Temas Relacionados</p>
        <a href="eys-softskill.php">Softskill</a>
   </div>
  </div>

</div>  


