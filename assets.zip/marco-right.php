

<div  style="display: inline-block; width:100%" > 
  <div style="border-right:1px solid black;  float:left;  width:20%; height: 100vh; padding:1vw;">
    <div style="margin-top: 80px; ">
        <div style=" width: 10vw;  margin:auto ; padding:1px; border-radius:50%; " >
    				<div class="w3-card-4" style="margin: auto;   width:100%; border-top:5px solid green;  border-bottom:5px solid green; padding:0.5em; height:200px;border-radius:50%;">
         				<img id="foto" style="border-radius:50%; width:100%; height:100%;" src="http://educaysoft.org/images/coordinador-MTI.png" alt="El coordinador del programa" >
    				</div>
<center><span id="elnombre" style="padding:5px; border:1px solid gray; margin:0; background-color: green; color:white; text-shadow: 1px 1px black; ">Kevin Aguilar</span></center>
<hr>
			  </div>

    </div>
    <br>
    <div id="blog-indice">
        <p>Indice</p>
        <a href="#softskilleducacion"> softskill en la educación</a>
    </div>

</div>


